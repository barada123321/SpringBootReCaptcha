package com.bpm.service;

import java.util.List;

import com.bpm.model.Employee;

public interface IEmployeeService {
	
	void createEmployee(Employee employee);
	List<Employee> getAllEmployees();
}
